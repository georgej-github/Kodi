import AlphaUIUtils

AlphaUIUtils.CloseLauncher()
