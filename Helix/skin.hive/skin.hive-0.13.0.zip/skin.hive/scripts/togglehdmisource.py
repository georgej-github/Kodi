import AlphaUIUtils

AlphaUIUtils.ToggleHDMISource()