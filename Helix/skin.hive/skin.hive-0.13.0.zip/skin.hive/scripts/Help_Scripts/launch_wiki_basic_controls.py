import xbmc
import subprocess
subprocess.Popen('cmd /c start http://kodi.wiki/view/Home_screen_and_basic_controls')