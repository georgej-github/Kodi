from ctypes import windll

windll.user32.ExitWindowsEx(0, 1)