import AlphaUIUtils

AlphaUIUtils.CloseLauncher()